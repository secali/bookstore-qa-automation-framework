# 📚 BookStore QA Sandbox

Aplicación web full-stack para la gestión de un catálogo de libros.
Incluye una API REST documentada con Swagger y una interfaz web en React.

Este paquete contiene el entorno listo para ejecutar: no necesitas compilar nada.

| Servicio   | Descripción                                  | URL local                              |
|------------|----------------------------------------------|----------------------------------------|
| `frontend` | Interfaz web                                 | http://localhost:3000                  |
| `backend`  | API REST                                     | http://localhost:5000/api              |
| Swagger UI | Documentación interactiva de la API          | http://localhost:5000/api/docs         |
| OpenAPI    | Especificación JSON                          | http://localhost:5000/api/docs.json    |
| `mongo`    | MongoDB 7 (volumen persistente `mongo-data`) | `mongodb://localhost:27017/bookstore`  |

---

## 📦 Contenido del paquete

| Archivo                     | Descripción                                         |
|-----------------------------|-----------------------------------------------------|
| `bookstore-images.tar`      | Imágenes Docker de la aplicación (frontend y backend) |
| `docker-compose.yml`        | Orquesta los tres servicios                         |
| `README.md`                 | Este documento                                      |
| `CANDIDATE_INSTRUCTIONS.md` | Descripción del reto técnico                        |

---

## 🚀 Puesta en marcha

Requisitos: **Docker Desktop** (o Docker Engine + Compose v2) y conexión a internet para descargar la imagen oficial de MongoDB la primera vez.

Abre una terminal en la carpeta donde descomprimiste el paquete y ejecuta:

```bash
# 1. Cargar las imágenes de la aplicación en Docker (solo la primera vez)
docker load -i bookstore-images.tar

# 2. Levantar el entorno
docker compose up -d
```

Espera a que los tres contenedores estén `healthy` (puedes comprobarlo con `docker compose ps`) y abre http://localhost:3000.

Comandos útiles:

```bash
docker compose ps                 # estado de los servicios
docker compose logs -f backend    # ver logs de la API
docker compose restart backend    # reiniciar la API
docker compose down               # detener (conserva los datos)
docker compose down -v            # detener y BORRAR la base de datos (reset total)
```

### Credenciales por defecto (seed)

El backend crea automáticamente, en cada arranque, el siguiente usuario si no existe:

| Email               | Password   | Rol   |
|---------------------|------------|-------|
| `admin@sandbox.com` | `admin123` | admin |

Si la colección `books` está vacía, también se insertan **5 libros de ejemplo**.

---

## 🔌 API REST

Todas las respuestas son JSON. Los errores siguen siempre el mismo formato:

```json
{ "code": "VALIDATION_ERROR", "message": "Validation failed.", "errors": { "isbn": "isbn must be a valid ISBN-10 or ISBN-13." } }
```

La documentación completa de endpoints está en Swagger: http://localhost:5000/api/docs

---

## 🖥️ Frontend

| Ruta        | Vista                                                                 |
|-------------|-----------------------------------------------------------------------|
| `/login`    | Inicio de sesión                                                      |
| `/register` | Registro (redirige a `/login` con mensaje de éxito)                   |
| `/books`    | Dashboard protegido: tabla, búsqueda, modal de creación/edición, modal de borrado |

---

## 🛠️ Solución de problemas

| Síntoma | Causa probable / solución |
|---------|---------------------------|
| `No such image: bookstore-qa-sandbox-...` | No se cargaron las imágenes: ejecuta `docker load -i bookstore-images.tar`. |
| `port is already allocated` | Los puertos 3000, 5000 o 27017 están en uso por otra aplicación. Libéralos o detén ese proceso. |
| Un contenedor no llega a `healthy` | Revisa `docker compose logs <servicio>`. Si persiste, `docker compose down -v` y vuelve a levantar. |
| Mac con chip Apple (M1/M2/M3…) | Las imágenes son `linux/amd64`; Docker Desktop las ejecuta mediante emulación. Funcionan, aunque pueden ir algo más lentas. |
